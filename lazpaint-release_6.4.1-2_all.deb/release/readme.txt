LazPaint v6.3 - A paint program made with Lazarus

This program is designed to draw like with Paint.Net, to experiment this kind of programming with Lazarus and to provide an example of use of BGRABitmap library.

LazPaint itself is under license GPLv3 which means it must remain opensource, whereas BGRABitmap library can be used in any application.